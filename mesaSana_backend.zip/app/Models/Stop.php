<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\MorphMany;

/**
 * Class Stop
 * @package App\Http\Models
 * @property MorphMany images
 * @property BelongsTo company
 * @property int id
 * @property string description
 * @property string level
 * @property string status
 */
class Stop extends Model
{

    /**
     * The database table used by the model.
     *
     * @var string
     */
    public $table = 'stops';

    protected $guarded = [];
    const STATUS_ACTIVE = 'ACTIVE';
    const STATUS_INACTIVE = 'INACTIVE';
    /**
     * Indicates if the model should be timestamped.
     *
     * @var bool
     */
    public $timestamps = true;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = [
        'name',
        'description',
        'transport_geolocation_id',
        'buses_linea_id',
        'status'
    ];

    /**
     * The attributes that should be casted to native types.
     *
     * @var array
     */
    protected $casts = [
        'status' => 'string',
        'buses_linea_id' => 'integer',
        'transport_geolocation_id' => 'integer',
        'name' => 'string',
        'description' => 'string',
        
    ];

    /**
     * The attributes that should be mutated to dates.
     *
     * @var array
     */
    protected $dates = [
        'created_at',
        'updated_at',
    ];

    public function geolocation()
    {
        return $this->belongsTo(TransportGeolocation::class, 'transport_geolocation_id');
    }
    public function lineBus()
    {
        return $this->belongsTo(BusesLine::class, 'buses_linea_id');
    }

}
