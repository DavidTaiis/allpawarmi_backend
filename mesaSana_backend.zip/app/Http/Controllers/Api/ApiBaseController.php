<?php

namespace App\Http\Controllers\Api;

//use Dingo\Api\Routing\Helpers;
use Illuminate\Routing\Controller;

class ApiBaseController extends Controller
{
//    use Helpers;
}