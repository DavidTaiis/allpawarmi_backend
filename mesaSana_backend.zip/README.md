
Pasos para configurar el proyecto:

Paso 1: Checkout del proyecto
Paso 2: Generar el archivo .env- con la configuración de la base de datos
Paso 3: Ejecutar 'composer install' en la raíz del proyecto
Paso 4: Ejecutar 'php artisan key:generate' en la raíz del proyecto
