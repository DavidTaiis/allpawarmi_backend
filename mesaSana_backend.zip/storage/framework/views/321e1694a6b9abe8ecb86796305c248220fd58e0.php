<!--begin::Aside-->
<div class="aside aside-left aside-fixed d-flex flex-column flex-row-auto" id="kt_aside">
    <!--begin::Brand-->
    
        <div class="img-aside">
            <!--begin::Logo-->
                <img  class="img-logo" alt="Logo" src="<?php echo e(asset("images/splash.png"), false); ?>"/>
        </div>

       
    <!--end::Brand-->
    <!--begin::Aside Menu-->
    <div class="aside-menu-wrapper flex-column-fluid" id="kt_aside_menu_wrapper">
        <!--begin::Menu Container-->
        <?php echo $menu; ?>

        <!--end::Menu Container-->
    </div>
    <!--end::Aside Menu-->
</div>
<!--end::Aside--><?php /**PATH C:\xampp\htdocs\mesaSana_backend\resources\views/layouts/partials2/sidebar.blade.php ENDPATH**/ ?>