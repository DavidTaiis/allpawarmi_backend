<div class="modal fade" id="<?php echo e(isset($id)? $id:'modal', false); ?>" role="dialog"
     aria-labelledby="exampleModalLongTitle" aria-hidden="true">
    <div class="modal-dialog <?php echo e(isset($size)? $size:'', false); ?>" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">
                    <?php echo e($title, false); ?>

                </h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i aria-hidden="true" class="ki ki-close"></i>
                </button>
            </div>
            <div class="modal-body">
                <div class="container_modal">
                    <?php if(isset($body)): ?>
                        <?php echo $body; ?>

                    <?php endif; ?>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary"  data-dismiss="modal">
                    Cerrar
                </button>
                <?php $__currentLoopData = $action_buttons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_button): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <button type="<?php echo e(isset($item_button['type'])?$item_button['type']:'button', false); ?>"
                            form="<?php echo e(isset($item_button['form'])?$item_button['form']:'', false); ?>"
                            id="<?php echo e(isset($item_button['id'])? $item_button['id']: '', false); ?>"
                            class="btn <?php echo e(isset($item_button['color'])? $item_button['color']: 'btn-primary', false); ?>"
                            onclick="<?php echo e(isset($item_button['handler_js'])?$item_button['handler_js']:'', false); ?>">
                        <?php echo e($item_button['label'], false); ?>

                    </button>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\lady3\OneDrive\Área de Trabalho\mesaSana_backend\resources\views/partials/modal.blade.php ENDPATH**/ ?>