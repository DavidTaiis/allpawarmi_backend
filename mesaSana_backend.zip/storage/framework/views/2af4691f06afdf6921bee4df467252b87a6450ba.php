<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.admin_view',[
    'title'=>'Lista de vendedoras',
    'icon'=>'<i class="flaticon-cogwheel-2"></i>',
    'id_table'=>'farmer_table',
      ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      
    <input id="action_list" type="hidden" value="<?php echo e(route("listDataFarmer"), false); ?>"/>
    <input id="action_index_product" type="hidden" value="<?php echo e(route("indexViewProduct"), false); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('additional-scripts'); ?>
    <script src="<?php echo e(asset("js/app/farmer/index.js"), false); ?>"></script>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\mesaSana_backend\resources\views/farmers/index.blade.php ENDPATH**/ ?>