<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.admin_view',[
    'title'=>'Administración de asociaciones',
    'icon'=>'<i class="flaticon-cogwheel-2"></i>',
    'id_table'=>'association_table',
    'action_buttons'=>[
        [
        'label'=>'Crear',
        'icon'=>'<i class="la la-plus"></i>',
        'handler_js'=>'newAssociation()',
        'color'=>'btn-primary'
        ],
      ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.modal',[
    'title'=>'Crear Asociación',
    'id'=>'modal',
    'size'=>'modal-lg',
    'action_buttons'=>[
        [
        'type'=>'submit',
        'form'=>'association_form',
        'id'=>'btn_save',
        'label'=>'Guardar',
        'color'=>'btn-primary'
        ],
     ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <input id="action_get_form" type="hidden" value="<?php echo e(route("getFormAssociations"), false); ?>"/>
    <input id="action_save" type="hidden" value="<?php echo e(route("saveAssociations"), false); ?>"/>
    <input id="action_list" type="hidden" value="<?php echo e(route("listDataAssociations"), false); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('additional-scripts'); ?>
    <script src="<?php echo e(asset("js/app/association/index.js"), false); ?>"></script>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\mesaSana_backend\resources\views/association/index.blade.php ENDPATH**/ ?>