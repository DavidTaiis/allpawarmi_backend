<?php $__env->startSection('content'); ?>
<div class="bg-white " style="margin-top: 0px ; text-align: center; width: 1050px ; align-self: center;">
    
      <br> 
      <div class="d-flex flex-column mb-10 mb-md-0">
    <label style="text-aling: center"><b>Información de la Línea de Bus</b> </label><br>
   <span><label><b>Nombre :</b> </label>
    <label><?php echo e($busesLine->name, false); ?> </label></span>
    <span><label><b>Precio :</b> </label>
    <label><?php echo e($busesLine->price, false); ?> </label></span>
    <span><label><b>Estado :</b> </label>
      <?php if($busesLine->status == 'ACTIVE'): ?>
      <label> Activo</label></span>
      <?php else: ?>
      <label>Inactivo </label></span>
      <?php endif; ?>
      </div> </div> 
    
  <br><br><br>
    <?php echo $__env->make('stop.table_stop_view',[
    'title'=>'Administración de paradas',
    'icon'=>'<i class="flaticon-cogwheel-2"></i>',
    'id_table'=>'stop_table',
    'action_buttons'=>[
        [
        'label'=>'Crear Paradas',
        'icon'=>'<i class="la la-plus"></i>',
        'handler_js'=>'newStop()',
        'color'=>'btn-primary'
        ],
      ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.modal',[
    'title'=>'Crear Parada',
    'id'=>'stop_modal',
    'size'=>'modal-lg',
    'action_buttons'=>[
        [
        'type'=>'submit',
        'form'=>'stop_form',
        'id'=>'btn_save',
        'label'=>'Guardar',
        'color'=>'btn-primary'
        ],
     ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <input id="action_get_form_stop" type="hidden" value="<?php echo e(route("getFormStop", $busesLine->id), false); ?>"/>
    <input id="action_save_stop" type="hidden" value="<?php echo e(route("saveStop"), false); ?>"/>
    <input id="action_load_stops" type="hidden" value="<?php echo e(route("getListDataStop", $busesLine->id), false); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('additional-scripts'); ?>
    <script src="<?php echo e(asset("js/app/stop/index.js"), false); ?>"></script>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\mesaSana_backend\resources\views/stop/index.blade.php ENDPATH**/ ?>