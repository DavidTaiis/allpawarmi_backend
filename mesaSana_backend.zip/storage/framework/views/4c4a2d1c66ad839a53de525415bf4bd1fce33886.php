<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.admin_view',[
    'title'=>'Administración de Lineas de buses',
    'icon'=>'<i class="flaticon-cogwheel-2"></i>',
    'id_table'=>'busesLine_table',
    'action_buttons'=>[
        [
        'label'=>'Crear',
        'icon'=>'<i class="la la-plus"></i>',
        'handler_js'=>'newbusesLine()',
        'color'=>'btn-primary'
        ],
      ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.modal',[
    'title'=>'Crear linea de bus',
    'id'=>'modal',
    'size'=>'modal-lg',
    'action_buttons'=>[
        [
        'type'=>'submit',
        'form'=>'busesLine_form',
        'id'=>'btn_save',
        'label'=>'Guardar',
        'color'=>'btn-primary'
        ],
     ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <input id="action_get_form" type="hidden" value="<?php echo e(route("getFormBusesLine"), false); ?>"/>
    <input id="action_save" type="hidden" value="<?php echo e(route("saveBusesLine"), false); ?>"/>
    <input id="action_list" type="hidden" value="<?php echo e(route("listDataBusesLine"), false); ?>"/>
    <input id="action_index_stops" type="hidden" value="<?php echo e(route("indexViewStop"), false); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('additional-scripts'); ?>
    <script src="<?php echo e(asset("js/app/busesLine/index.js"), false); ?>"></script>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\mesaSana_backend\resources\views/busesline/index.blade.php ENDPATH**/ ?>