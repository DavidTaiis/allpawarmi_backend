<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.admin_view',[
    'title'=>'Administración de noticias',
    'icon'=>'<i class="flaticon-cogwheel-2"></i>',
    'id_table'=>'news_table',
    'action_buttons'=>[
        [
        'label'=>'Crear',
        'icon'=>'<i class="la la-plus"></i>',
        'handler_js'=>'newNews()',
        'color'=>'btn-primary'
        ],
      ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.modal',[
    'title'=>'Crear noticia',
    'id'=>'modal',
    'size'=>'modal-lg',
    'action_buttons'=>[
        [
        'type'=>'submit',
        'form'=>'news_form',
        'id'=>'btn_save',
        'label'=>'Guardar',
        'color'=>'btn-primary'
        ],
     ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <input id="action_get_form" type="hidden" value="<?php echo e(route("getFormNews"), false); ?>"/>
    <input id="action_save" type="hidden" value="<?php echo e(route("saveNews"), false); ?>"/>
    <input id="action_list" type="hidden" value="<?php echo e(route("listDataNews"), false); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('additional-scripts'); ?>
    <script src="<?php echo e(asset("js/app/news/index.js"), false); ?>"></script>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\mesaSana_backend\resources\views/news/index.blade.php ENDPATH**/ ?>