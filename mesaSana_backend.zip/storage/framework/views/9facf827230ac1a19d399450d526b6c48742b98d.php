<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('partials.admin_view',[
    'title'=>'Administración de roles',
    'icon'=>'<i class="flaticon-cogwheel-2"></i>',
    'id_table'=>'role_table',
    'action_buttons'=> [
        [
        'label'=>'Crear',
        'icon'=>'<i class="la la-plus"></i>',
        'handler_js'=>'newRole()',
        'color'=>'btn-primary'
        ],
      ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.modal',[
    'title'=>'Crear Role',
    'id'=>'modal',
    'size'=>'modal-lg',
    'action_buttons'=>[
        [
        'type'=>'submit',
        'form'=>'role_form',
        'id'=>'btn_save',
        'label'=>'Guardar',
        'color'=>'btn-primary'
        ],
     ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <input id="action_get_form" type="hidden" value="<?php echo e(action("Rbac\RoleController@getFormRole"), false); ?>"/>
    <input id="action_unique_name" type="hidden" value="<?php echo e(action("Rbac\RoleController@postIsNameUnique"), false); ?>"/>
    <input id="action_save_role" type="hidden" value="<?php echo e(action("Rbac\RoleController@postSave"), false); ?>"/>
    <input id="action_load_roles" type="hidden"
           value="<?php echo e(action("Rbac\RoleController@getList"), false); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('additional-scripts'); ?>
    <script src="<?php echo e(asset("js/app/rbac/role.js"), false); ?>"></script>
<?php $__env->stopSection(); ?><?php /**PATH C:\Users\lady3\OneDrive\Área de Trabalho\mesaSana_backend\resources\views/rbac/roles/index.blade.php ENDPATH**/ ?>