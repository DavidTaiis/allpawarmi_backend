<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('partials.admin_view',[
    'title'=>'Administración de parámetros de imagen',
    'icon'=>'<i class="flaticon-cogwheel-2"></i>',
    'id_table'=>'image_parameter_table',
    'action_buttons'=>[
        [
        'label'=>'Crear',
        'icon'=>'<i class="la la-plus"></i>',
        'handler_js'=>'newListener()',
        'color'=>'btn-primary'
        ],
      ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.modal',[
    'title'=>'Crear parámetro imagen',
    'id'=>'modal',
    'action_buttons'=>[
        [
        'type'=>'submit',
        'form'=>'image_parameter_form',
        'id'=>'btn_save',
        'label'=>'Guardar',
        'color'=>'btn-primary'
        ],
     ]
    ], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <input id="action_get_form"  type="hidden" value="<?php echo e(action("Multimedia\ImageParameterController@getForm"), false); ?>"/>
    <input id="action_unique_name" type="hidden" value="<?php echo e(action("Multimedia\ImageParameterController@postIsNameUnique"), false); ?>"/>
    <input id="action_unique_entity" type="hidden" value="<?php echo e(action("Multimedia\ImageParameterController@postIsEntityUnique"), false); ?>"/>
    <input id="action_save" type="hidden" value="<?php echo e(action("Multimedia\ImageParameterController@postSave"), false); ?>"/>
    <input id="action_list" type="hidden"
           value="<?php echo e(action("Multimedia\ImageParameterController@getList"), false); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('additional-scripts'); ?>
    <script src="<?php echo e(asset("js/app/image-parameter/index.js"), false); ?>"></script>
<?php $__env->stopSection(); ?><?php /**PATH C:\xampp\htdocs\mesaSana_backend\resources\views/image-parameter/index.blade.php ENDPATH**/ ?>