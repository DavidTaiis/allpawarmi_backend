<head><base href="">
    <meta charset="utf-8" />
    <title>MesaSana</title>
    <meta name="description" content=""/>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no" />
    <link rel="canonical" href="https://keenthemes.com/metronic" />
    <meta name="csrf-token" content="<?php echo e(csrf_token(), false); ?>">

    <!--begin::Fonts-->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700" />
    <!--end::Fonts-->
    <!--begin::Page Vendors Styles(used by this page)-->
    <link href="<?php echo e(asset("theme/metronic/plugins/custom/fullcalendar/fullcalendar.bundle.css"), false); ?>" rel="stylesheet" type="text/css" />
    <!--end::Page Vendors Styles-->
    <!--begin::Global Theme Styles(used by all pages)-->
    <link href="<?php echo e(asset("theme/metronic/plugins/global/plugins.bundle.css"), false); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset("theme/metronic/plugins/custom/prismjs/prismjs.bundle.css"), false); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset("theme/metronic/css/style.bundle.css"), false); ?>" rel="stylesheet" type="text/css" />
    <!--end::Global Theme Styles-->
    <!--begin::Layout Themes(used by all pages)-->
    <link href="<?php echo e(asset("theme/metronic/css/themes/layout/header/base/light.css"), false); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset("theme/metronic/css/themes/layout/header/menu/light.css"), false); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset("theme/metronic/css/themes/layout/brand/dark.css"), false); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset("theme/metronic/css/themes/layout/aside/dark.css"), false); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset("theme/metronic/css/pages/login/login-3.css"), false); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset("css/custom_form.css"), false); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset("theme/metronic/plugins/custom/datatables/datatables.bundle.css"), false); ?>" rel="stylesheet" type="text/css"/>
    <link href="<?php echo e(asset("js/plugins/daterangepicker/daterangepicker.css"), false); ?>" rel="stylesheet"/>


    <!--end::Layout Themes-->
    <link rel="shortcut icon" href="<?php echo e(asset("images/promostock.png"), false); ?>"   />
    <link rel="icon" href="<?php echo e(asset("images/promostock.png"), false); ?>"> 
</head>

<?php /**PATH C:\Users\lady3\OneDrive\Área de Trabalho\mesaSana_backend\resources\views/layouts/partials2/head.blade.php ENDPATH**/ ?>