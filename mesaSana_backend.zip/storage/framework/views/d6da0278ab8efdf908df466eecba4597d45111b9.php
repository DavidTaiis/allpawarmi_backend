<?php $__env->startSection('content'); ?>
<br>
    <h1 style="text-align: center">Bienvenidos al administrador</h1>
<?php $__env->stopSection(); ?>


<?php /**PATH C:\xampp\htdocs\mesaSana_backend\resources\views/home.blade.php ENDPATH**/ ?>