<div class="content d-flex flex-column flex-column-fluid" id="kt_content">
	<!--begin::Entry-->
	<div class="d-flex flex-column-fluid">
		<!--begin::Container-->
		<div class="container">
			<!--begin::Card-->
			<div class="card card-custom">
				<div class="card-header">
					<div class="card-title">
						<span class="card-icon">
							<i class="flaticon-star text-success"></i>
						</span>
						<h3 class="card-label"><?php echo e($title, false); ?></h3>
					</div>
					<div class="card-toolbar">
						<?php if(isset($action_buttons) && is_array($action_buttons)): ?>
                <?php $__currentLoopData = $action_buttons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item_button): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="btn <?php echo e(isset($item_button['color'])? $item_button['color']: 'btn-primary', false); ?> mr-3" href="#" onclick="<?php echo e($item_button['handler_js'], false); ?>">
                        <?php echo $item_button['icon']; ?>  <?php echo e($item_button['label'], false); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php endif; ?>
					</div>
				</div>
				<div class="card-body">
					<!--begin: Datatable-->
					<table class="table table-bordered table-hover table-checkable"  id="<?php echo e(isset($id_table) ? $id_table : 'kt_datatable', false); ?>" style="margin-top: 13px !important">
					
					</table>
					<!--end: Datatable-->
				</div>
			</div>
			<!--end::Card-->
		</div>
		<!--end::Container-->
	</div>
	<!--end::Entry-->
</div>
<!--end::Content--><?php /**PATH C:\Users\lady3\OneDrive\Área de Trabalho\mesaSana_backend\resources\views/partials/admin_view.blade.php ENDPATH**/ ?>